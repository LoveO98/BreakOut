﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace BreakOut_Ver1
{
    internal class Padle
    {
        public Vector2 pos;
        
        public int stopX;
        public Texture2D padleTex;
        public int velocity;
        Random rnd = new Random();
        public Rectangle hitBox;
        public int screenWidth;
        
        public MouseState mouseState;
        public MouseState oldMouse;
        public Vector2 velChange;
        public static int velChangeX;
        public static int velChangeY;


        public static System.Drawing.Point MousePosition { get; }

        public Padle(Texture2D padleTex, Vector2 pos, int velocity, int screenWidth)
        {
            this.pos = pos;                       
            this.padleTex = padleTex;
            this.velocity = velocity;
            this.screenWidth = screenWidth;
            this.stopX = screenWidth - padleTex.Width;
            this.hitBox = new Rectangle((int)pos.X, (int)pos.Y, padleTex.Width, padleTex.Height);
            

        }

        public void Update()
        {
            //if (pos.X <= 0 || pos.X >= stopX)
            //{
            //    velocity *= -1;
            //}

            //pos.X = pos.X + velocity;
            //hitBox.X = (int)pos.X;
            //hitBox.Y = (int)pos.Y;

            //this.pos.X = ball.pos.X;
            this.oldMouse = mouseState;
            this.mouseState = Mouse.GetState();
            this.pos.X = (int)mouseState.X;
            hitBox.X = (int)pos.X;
            hitBox.Y = (int)pos.Y;
            velChangeX = (int)mouseState.X - (int)oldMouse.X;
            velChangeY = (int)mouseState.Y - (int)oldMouse.Y;
            //this.velChange = new Vector2((int)mouseState.X-(int)oldMouse.X, (int)mouseState.Y-(int)oldMouse.Y);
        }

        public void Draw(SpriteBatch sb)
        {
            sb.Draw(padleTex, pos, Color.White);
        }
    }
}
