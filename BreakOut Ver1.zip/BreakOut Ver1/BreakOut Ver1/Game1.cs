﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using SharpDX.Direct2D1.Effects;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TrackBar;

namespace BreakOut_Ver1
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager graphics;
        private SpriteBatch spriteBatch;
        Texture2D ballTex;
        Texture2D brickTex;
        Texture2D padleTex;
        public int screenWidth;
        public int screenHeight;
        public int nrXBrick = 14;
        public int nrYBrick = 4;
        Vector2 ballPos;
        public int stopX;
        public int stopY;
        Ball ball;
        public Vector2 velocity;
        Brick brick;
        Brick[,] bricks;
        Padle padle;
        public int middleX;
        public int screenWidth2;
        public int points=0;
        public SpriteFont spritefont;
        Vector2 textPos = new Vector2(700, 500);
        public static int lives = 5;
        

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            

            base.Initialize();
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            ballTex = Content.Load<Texture2D>(@"ball_breakout");
            brickTex = Content.Load<Texture2D>(@"block_breakout");
            padleTex = Content.Load<Texture2D>(@"padle");
            screenWidth = graphics.PreferredBackBufferWidth = brickTex.Width * nrXBrick;
            screenHeight = graphics.PreferredBackBufferHeight = 1000;
            graphics.ApplyChanges();
            stopX = Window.ClientBounds.Width - ballTex.Width;
            stopY = Window.ClientBounds.Height - ballTex.Height;
            middleX = Window.ClientBounds.Width / 2;
            ballPos = new Vector2(500, 500);
            velocity = new Vector2(5, 15);
            ball = new Ball(ballTex, ballPos, stopX, stopY, velocity);
            Vector2 padlePos = new Vector2(middleX, 800);
            screenWidth2 = Window.ClientBounds.Width;
            padle = new Padle(padleTex, padlePos, 5, screenWidth2);

            bricks = new Brick[nrXBrick, nrYBrick];
            

            for (int i = 0; i < nrXBrick; i++)
            {
                for (int j = 0; j < nrYBrick; j++)
                {
                    int x = i * brickTex.Width;
                    int y = j * brickTex.Height;
                    bricks[i, j] = new Brick(brickTex, x, y, j);
                }
                
            }
            spritefont = Content.Load<SpriteFont>("spritefont1");

            



        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();
            ball.Update();
            padle.Update();
            for (int i = 0; i < bricks.GetLength(0); i++)
            {
                for (int j = 0; j < bricks.GetLength(1); j++)
                {
                    brick = bricks[i, j];
                    if (ball.hitBox.Intersects(brick.hitBox))
                    {
                        brick.isVisible = false;
                        ball.bounce = true;
                        points += 100;
                        
                    }
                }

            }
            if (ball.hitBox.Intersects(padle.hitBox))
            {
                ball.pBounce = true;
            }
            
            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);
            spriteBatch.Begin();

            ball.Draw(spriteBatch);
            padle.Draw(spriteBatch);

            for (int i = 0; i < bricks.GetLength(0); i++)
            {
                for (int j = 0; j < bricks.GetLength(1); j++)
                {
                    bricks[i, j].Draw(spriteBatch);
                }
                
            }
            spriteBatch.DrawString(spritefont, "Points: "+points, textPos, Color.Yellow);
            spriteBatch.DrawString(spritefont, "Lives;" + lives, new Vector2(700, 600), Color.Yellow);
            spriteBatch.End();
            base.Draw(gameTime);
        }
    }
}