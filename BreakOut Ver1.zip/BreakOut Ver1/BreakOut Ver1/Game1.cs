﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using SharpDX.Direct2D1.Effects;
using System;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TrackBar;

namespace BreakOut_Ver1
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager graphics;
        private SpriteBatch spriteBatch;
        Texture2D ballTex;
        Texture2D brickTex;
        Texture2D padleTex;
        Texture2D shieldMidTex;
        Texture2D shieldSideTex;
        Texture2D startStoryButtonTex;
        Texture2D multiplayButtonTex; //
        Texture2D coopButtonTex; //
        Texture2D vsButtonTex; //
        Texture2D exitButtonTex;//
        Texture2D backgroundTex; //
        Texture2D selectorTex; //
        Texture2D infiniteSoloButtonTex; //
        Texture2D highScoreTex; //

        public int screenWidth;
        public int screenHeight;
        public int nrXBrick = 14;
        public int nrYBrick = 8;
        
        public int stopX;
        public int stopY;
        Ball ball;
        Menu menu;
        public Vector2 velocity;
        Brick brick;
        Brick[,] bricks;
        Padle padle;
        public int middleX;
        public static int screenWidth2;
        public int points=0;
        public SpriteFont spritefont;
        Vector2 textPos = new Vector2(700, 500);
        public static int lives = 1000;
        public enum GameState
        {
            start, 
            menu, 
            infiniteSolo, 
            mpVs, 
            mpCoop, 
            highScore,
            level1, 
            level2, 
            level3, 
            level4, 
            level5, 
            levelF, 
            score, 
            endScreen
        }
        
        public static GameState currentGS = GameState.menu;
        //public KeyboardState keyboardState = Keyboard.GetState();
        public static bool quitThisBitch;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            

            base.Initialize();
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            ballTex = Content.Load<Texture2D>(@"ball_breakout");
            brickTex = Content.Load<Texture2D>(@"block_breakout");
            padleTex = Content.Load<Texture2D>(@"SpaceShip1");
            shieldSideTex = Content.Load<Texture2D>(@"SpaceShip1ShieldSide");
            shieldMidTex = Content.Load<Texture2D>(@"SpaceShip1ShieldMid");
            selectorTex = Content.Load<Texture2D>(@"Selector");
            startStoryButtonTex = Content.Load<Texture2D>(@"StartStory");
            multiplayButtonTex = Content.Load<Texture2D>(@"Multiplayer");
            coopButtonTex = Content.Load<Texture2D>(@"CoOp");
            vsButtonTex = Content.Load<Texture2D>(@"Competetive");
            exitButtonTex = Content.Load<Texture2D>(@"Exit");
            backgroundTex = Content.Load<Texture2D>(@"PlaceHolderBG");
            infiniteSoloButtonTex = Content.Load<Texture2D>(@"Infinite1p");
            highScoreTex = Content.Load<Texture2D>(@"HighScores");

            menu = new Menu(startStoryButtonTex, multiplayButtonTex, coopButtonTex, vsButtonTex, exitButtonTex, backgroundTex, selectorTex, infiniteSoloButtonTex, highScoreTex);

            screenWidth = graphics.PreferredBackBufferWidth = 1920;
            screenHeight = graphics.PreferredBackBufferHeight = 1080;
            graphics.ApplyChanges();


            stopX = Window.ClientBounds.Width - ballTex.Width;
            stopY = Window.ClientBounds.Height - ballTex.Height;
            middleX = Window.ClientBounds.Width / 2;
            
            velocity = new Vector2(5, 7);
            ball = new Ball(ballTex, stopX, stopY, velocity);
            Vector2 padlePos = new Vector2(middleX, 800);
            screenWidth2 = Window.ClientBounds.Width;
            padle = new Padle(padleTex, shieldMidTex, shieldSideTex, padlePos, 5, screenWidth2);

            bricks = new Brick[nrXBrick, nrYBrick];
            

            for (int i = 0; i < nrXBrick; i++)
            {
                for (int j = 0; j < nrYBrick; j++)
                {
                    int x = i * brickTex.Width;
                    int y = j * brickTex.Height;
                    bricks[i, j] = new Brick(brickTex, x, y, j);
                }
                
            }
            int powerupBricks = 0;
            while(powerupBricks < 10)
            {
                Random rand = new Random();

                foreach (Brick brick in bricks)
                {

                    if (rand.Next(0, 10) == 10)
                    {
                        brick.powerupBricks = true;
                        powerupBricks++;
                    }
                    
                }
                 
            }
            spritefont = Content.Load<SpriteFont>("spritefont1");
            
            



        }

        protected override void Update(GameTime gameTime)
        {
            if (quitThisBitch)
            {
                Exit();
            }

            menu.Update(gameTime);

            if(lives <= 0)
            {
                currentGS = GameState.start;
            }

            

            switch (currentGS)
            {
                case GameState.menu:


                    break;


                case GameState.infiniteSolo:


                    for (int i = 0; i < bricks.GetLength(0); i++)
                    {
                        for (int j = 0; j < bricks.GetLength(1); j++)
                        {
                            bricks[i,j].Update(gameTime);
                        }
                    }
                    
                    ball.Update(padle);
                    padle.Update(gameTime);
                    for (int i = 0; i < bricks.GetLength(0); i++)
                    {
                        for (int j = 0; j < bricks.GetLength(1); j++)
                        {
                            brick = bricks[i, j];
                            if (ball.hitBox.Intersects(brick.hitBox))
                            {
                                brick.isVisible = false;
                                ball.bounce = true;
                                points += 100;

                            }
                        }

                    }
                    if (ball.hitBox.Intersects(padle.hitBoxMid))
                    {
                        if(ball.hitBox.Bottom-5 <= padle.hitBoxMid.Top)
                        {
                            ball.pBounceMid = true;
                            padle.pBounceMid = true;
                        }
                        
                    }
                    else if (ball.hitBox.Intersects(padle.hitBoxLeft))
                    {
                        if(ball.hitBox.Bottom - 5 <= padle.hitBoxLeft.Top)
                        {
                            ball.pBounceLeft = true;
                            padle.pBounceLeft = true;
                        }
                        else
                        {
                            ball.pBounceSideL = true;
                            padle.pBounceLeft = true;
                        }
                        
                    }
                    else if (ball.hitBox.Intersects(padle.hitBoxRight))
                    {
                        if (ball.hitBox.Bottom - 5 <= padle.hitBoxRight.Top)
                        {
                            ball.pBounceRight = true;
                            padle.pBounceRight = true;
                        }
                        else
                        {
                            ball.pBounceSideR = true;
                            padle.pBounceRight = true;
                        }

                    }

                    break;
            }

            

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);
            spriteBatch.Begin();

            switch (currentGS)
            {

                case GameState.menu:
                    menu.Draw(spriteBatch);
                    
             
                    
                    break;


                case GameState.infiniteSolo:

                    ball.Draw(spriteBatch);
                    padle.Draw(spriteBatch);

                    for (int i = 0; i < bricks.GetLength(0); i++)
                    {
                        for (int j = 0; j < bricks.GetLength(1); j++)
                        {
                            bricks[i, j].Draw(spriteBatch);
                        }

                    }
                    spriteBatch.DrawString(spritefont, "Points: " + points, textPos, Color.Yellow);
                    spriteBatch.DrawString(spritefont, "Lives;" + lives, new Vector2(700, 600), Color.Yellow);
                    

                    break;
            }


            
            spriteBatch.End();
            base.Draw(gameTime);
        }
    }
}