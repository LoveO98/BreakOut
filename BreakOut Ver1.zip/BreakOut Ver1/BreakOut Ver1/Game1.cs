﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TrackBar;

namespace BreakOut_Ver1
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager graphics;
        private SpriteBatch spriteBatch;
        Texture2D ballTex;
        Texture2D brickTex;
        Texture2D padleTex;
        public int screenWidth;
        public int screenHeight;
        public int nrXBrick = 14;
        public int nrYBrick = 4;
        Vector2 ballPos;
        public int stopX;
        public int stopY;
        Ball ball;
        public Vector2 velocity;
        Brick brick;
        Brick[,] bricks;
        

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            

            base.Initialize();
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            ballTex = Content.Load<Texture2D>(@"ball_breakout");
            brickTex = Content.Load<Texture2D>(@"block_breakout");
            padleTex = Content.Load<Texture2D>(@"padle");
            screenWidth = graphics.PreferredBackBufferWidth = brickTex.Width * nrXBrick;
            screenHeight = graphics.PreferredBackBufferHeight = 1000;
            graphics.ApplyChanges();
            stopX = Window.ClientBounds.Width - ballTex.Width;
            stopY = Window.ClientBounds.Height - ballTex.Height;
            ballPos = new Vector2(500, 500);
            velocity = new Vector2(5, 15);
            ball = new Ball(ballTex, ballPos, stopX, stopY, velocity);


            bricks = new Brick[nrXBrick, nrYBrick];

            for (int i = 0; i < nrXBrick; i++)
            {
                for (int j = 0; j < nrYBrick; j++)
                {
                    int x = i * brickTex.Width;
                    int y = j * brickTex.Height;
                    bricks[i, j] = new Brick(brickTex, x, y, j);
                }
                
            }
            



            }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();
            ball.Update();
            for (int i = 0; i < bricks.GetLength(0); i++)
            {
                for (int j = 0; j < bricks.GetLength(1); j++)
                {
                    brick = bricks[i, j];
                    if (ball.hitBox.Intersects(brick.hitBox))
                    {
                        brick.isVisible = false;
                        ball.bounce = true;
                        
                    }
                }

            }
            

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);
            spriteBatch.Begin();

            ball.Draw(spriteBatch);


            for (int i = 0; i < bricks.GetLength(0); i++)
            {
                for (int j = 0; j < bricks.GetLength(1); j++)
                {
                    bricks[i, j].Draw(spriteBatch);
                }
                
            }


            spriteBatch.End();
            base.Draw(gameTime);
        }
    }
}