﻿
using var game = new BreakOut_Ver1.Game1();
game.Run();
