﻿using System;
using System.Collections.Generic;
using System.Linq;
//using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;


namespace BreakOut_Ver1
{
    internal class Ball
    {
        public Vector2 pos = new Vector2(500,500);
        public int stopX;
        public int stopY;
        public Texture2D ballTex;
        public Vector2 velocity;
        Random rnd = new Random();
        public Rectangle hitBox;
        public bool bounce;
        public bool pBounceLeft;
        public bool pBounceMid;
        public bool pBounceRight;
        public bool pBounceSideL;
        public bool pBounceSideR;
        public int velChangeX;
        public bool isBalling;
        public bool keyCooldown = true;

        public Ball(Texture2D ballTex, int stopX, int stopY,Vector2 velocity)
        {
            this.ballTex = ballTex;
            
            this.stopX = stopX;
            this.stopY = stopY;
            this.velocity = velocity;
            this.hitBox = new Rectangle((int)pos.X, (int)pos.Y, ballTex.Width, ballTex.Height);


        }
        public void Update(Padle padle)
        {


            KeyboardState keyboardState = Keyboard.GetState();

            if (keyboardState.IsKeyUp(Keys.X))
            {
                keyCooldown = false;
            }
            
            if (keyboardState.IsKeyDown(Keys.X) && !keyCooldown)
            {
                isBalling = true;
            }

            if (!isBalling)
            {
                pos.X = padle.pos.X + padle.padleTex.Width / 2 - ballTex.Width / 2;
                pos.Y = padle.pos.Y - padle.padleTex.Height / 2 - ballTex.Height / 2;
                
            }
            else
            {
                if (bounce)
                {
                    velocity.Y *= -1;
                    bounce = false;
                }

                if (pBounceMid)
                {
                    velocity.Y *= -1;
                    velocity.X = 0;



                    pBounceMid = false;

                }

                if (pBounceRight)
                {
                    velocity.Y *= -1;
                    velocity.X += 3;

                    pBounceRight = false;
                }

                if (pBounceLeft)
                {
                    velocity.Y *= -1;
                    velocity.X -= 3;

                    pBounceLeft = false;
                }

                if (pos.X <= 0 || pos.X >= stopX)
                {

                    velocity.X *= -1;
                }

                if (pBounceSideL)
                {
                    velocity.X = Math.Abs(velocity.X);
                    if (velocity.X == 0)
                    {
                        velocity.X = 5;
                    }
                    velocity.X *= -1;
                    pBounceSideL = false;
                }

                if (pBounceSideR)
                {

                    velocity.X = Math.Abs(velocity.X);
                    if (velocity.X == 0)
                    {
                        velocity.X = 5;
                    }
                    pBounceSideR = false;
                }

                if (pos.Y <= 0)
                {

                    velocity.Y *= -1;
                }

                if (pos.Y >= stopY)
                {
                    isBalling = false;
                    Game1.lives--;
                }

                if (velocity.X > 9)
                {
                    velocity.X = 9;
                }

                if (velocity.X < -9)
                {
                    velocity.X = -9;
                }


                pos.X = pos.X + velocity.X;
                pos.Y = pos.Y + velocity.Y;
                hitBox.X = (int)pos.X;
                hitBox.Y = (int)pos.Y;

            }
            

        }

        public void Draw(SpriteBatch sb)
        {
            sb.Draw(ballTex, pos, Color.Red);
            
        }

    }
}
