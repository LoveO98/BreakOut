﻿using System;
using System.Collections.Generic;
using System.Linq;
//using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;


namespace BreakOut_Ver1
{
    internal class Ball
    {
        public Vector2 pos;
        public int stopX;
        public int stopY;
        public Texture2D ballTex;
        public Vector2 velocity;
        Random rnd = new Random();
        public Rectangle hitBox;
        public bool bounce;

        public Ball(Texture2D ballTex, Vector2 pos, int stopX, int stopY,Vector2 velocity)
        {
            this.ballTex = ballTex;
            this.pos = pos;
            this.stopX = stopX;
            this.stopY = stopY;
            this.velocity = velocity;
            this.hitBox = new Rectangle((int)pos.X, (int)pos.Y, ballTex.Width, ballTex.Height);


        }


        public void Update()
        {
            if (bounce)
            {
                velocity.Y *= -1;
                bounce = false;
            }

            if(pos.X <= 0 || pos.X >= stopX) 
            {
                //if(pos.X <= 0)
                //{
                //    velocity.X = rnd.Next(-7, -1);
                //}
                //else if(pos.X >= stopX)
                //{
                //    velocity.X = rnd.Next(1, 8);
                //}
                velocity.X *= -1;
            }
             if(pos.Y <= 0 || pos.Y >= stopY)
            {
                //if (pos.Y <= 0 || pos.Y >= stopY)
                //{
                //    velocity.X += rnd.Next(-2, 3);
                //}
                
                velocity.Y *= -1;
            }

            pos.X = pos.X + velocity.X;
            pos.Y = pos.Y + velocity.Y;
            hitBox.X = (int)pos.X;
            hitBox.Y = (int)pos.Y;

        }

        public void Draw(SpriteBatch sb)
        {
            sb.Draw(ballTex, pos, Color.Red);
            
        }

    }
}
