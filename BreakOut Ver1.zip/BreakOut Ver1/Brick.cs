﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
//using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TrackBar;

namespace BreakOut_Ver1
{
    public class Brick
    {
        Texture2D brickTex;
        Vector2 pos;
        int row;
        public Rectangle hitBox;
        public bool isVisible = true;
        public bool powerupBricks;
        public int pwrUpBrick;
        
        Ball ball;
        public Brick(Texture2D brickTex, int posX, int posY, int row)
        {
            this.brickTex = brickTex;
            this.pos = new Vector2(posX, posY);
            this.row = row;
            this.hitBox = new Rectangle((int)pos.X, (int)pos.Y, brickTex.Width, brickTex.Height);

        }

        public void Update(GameTime gameTime)
        {


            if (!isVisible) 
            {
                this.hitBox = new Rectangle(-100, -100, 0, 0);
            }

            if(powerupBricks)
            {
                if (ball.hitBox.Intersects(hitBox))
                {
                    Random rnd = new Random();
                    pwrUpBrick = rnd.Next(1,7);

                    switch( pwrUpBrick )
                    {
                        case 1:
                            Game1.lives++;
                            break;

                        case 2:
                            ball.pierceBrick = true;
                            break;

                        case 3:

                            break;

                        case 4:

                            break;

                        case 5:

                            break;

                        case 6:

                            break;
                    }

                }
            }
        }


        public void Draw(SpriteBatch spriteBatch)
        {
            if (isVisible)
            {
                if (row == 0)
                {
                    spriteBatch.Draw(brickTex, pos, Color.Red);
                }
                else if (row == 1)
                {
                    spriteBatch.Draw(brickTex, pos, Color.Orange);
                }
                else if (row == 2)
                {
                    spriteBatch.Draw(brickTex, pos, Color.Yellow);
                }
                else if (row >= 3)
                {
                    spriteBatch.Draw(brickTex, pos, Color.Green);
                }
            }

            switch (pwrUpBrick)
            {
                case 1:

                    break;

                case 2:

                    break;

                case 3:

                    break;

                case 4:

                    break;

                case 5:

                    break;

                case 6:

                    break;
            }

        }
    }
}
